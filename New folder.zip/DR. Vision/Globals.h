/*
 * Globals.h
 *
 * Created: 13.7.2016 15:14:20
 *  Author: dejan.ristic
 */ 


#ifndef GLOBALS_H_
#define GLOBALS_H_

//extern Limit_Left;
//extern Limit_Right;



#endif /* GLOBALS_H_ */