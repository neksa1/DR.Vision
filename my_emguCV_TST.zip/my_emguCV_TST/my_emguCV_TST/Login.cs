﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DR.Vision_nm
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        public void btnLogin_Click(object sender, EventArgs e)
        {
          
        }

        public void textUsername_TextChanged(object sender, EventArgs e)
        {     
            
        }

        private void lbnPasword_Click(object sender, EventArgs e)
        {
           
        }

        private void lblUserName_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
        
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
